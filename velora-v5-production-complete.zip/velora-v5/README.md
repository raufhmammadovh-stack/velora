# VELORA — Expanded Production Foundation

This version expands the original foundation into a multi-surface social platform architecture.

## Screens
- Home / personalized feed
- Explore / user search
- Dating / swipe / preferences
- Matches
- Stories
- Create post
- Profile
- Messages / conversation
- Notifications
- Settings / privacy
- Hidden Admin Mode / Control Center

## Backend
Supabase Auth + Postgres + RLS + Storage + Realtime. Supabase Realtime supports Broadcast, Presence and database changes; for production chat, private channels and authorization should be used. See official docs: https://supabase.com/docs/guides/realtime/getting_started

## Expanded data
Adds saves, reposts, matches, reports and remote app configuration. App configuration lets admins remotely enable/disable major modules without rebuilding the mobile client.

## Still required for a real public launch
- production media upload pipeline and Storage policies
- Expo push credentials + server-side notification worker
- WebRTC/TURN or a managed calling provider for audio/video calls
- server-side moderation and abuse prevention
- CAPTCHA / rate limits
- location permission + geospatial query for Nearby
- legal documents and age/consent requirements
- security audit, penetration testing and load testing
- App Store / Google Play signing and release configuration

## Run
npm install
npx expo start

Then configure .env from .env.example and run both SQL migrations in Supabase.

## V5 consolidated documentation
- `README_V5.md` — architecture and setup
- `FEATURES_V5.md` — feature matrix
- `LAUNCH_CHECKLIST_V5.md` — public launch checklist
- `docs/PHONE_SETUP_AZ.md` — Android/phone instructions
- `docs/PRODUCTION_GAPS.md` — honest external integration boundary
- `docs/TEST_REPORT.md` — what was actually tested here
