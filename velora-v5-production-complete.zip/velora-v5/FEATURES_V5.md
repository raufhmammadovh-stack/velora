# VELORA V5 FEATURE MATRIX

| Area | Status in codebase | External production setup |
|---|---|---|
| Auth | Supabase Auth + profile trigger | Email/phone provider settings |
| Profiles | Real DB CRUD foundation | Storage for avatars |
| Feed/posts | DB + UI foundation | Media bucket + CDN policy |
| Stories | DB + UI foundation | Media bucket + cleanup job |
| Likes/comments/reposts/saves | DB + services | None beyond Supabase |
| Follow requests | DB foundation | Product-specific privacy rules can be tuned |
| Search | UI foundation | Add FTS/trigram index if scale demands |
| Dating/matching | Candidate/swipe DB functions | Age/market policy review |
| Nearby | Privacy switch + fields | Real geolocation permission + privacy review |
| Chat | Private membership + realtime foundation | Realtime enablement/monitoring |
| Group chat | Data model | UI/group management completion |
| Message tools | Reply/edit/delete/read/reaction/star/pin/draft model | None for core DB |
| Push | Token registration service | Expo/EAS + APNs/FCM + server sender |
| Audio/video calls | Signaling tables/service | WebRTC/TURN or managed provider |
| Moderation | Reports/blocks/restrict/admin foundation | Human moderation process |
| Verification | Request workflow | Email/SMS/identity vendor or manual review |
| Admin | Role/config/audit foundation | Privileged Edge Functions + MFA |
| Account deletion | 7-day request model | Scheduled worker/Edge Function |
| Analytics | DB/audit foundation | Privacy-compliant analytics provider |
| Security | RLS, rate-limit RPC, no client secrets | CAPTCHA/attestation, monitoring, backups |
| Localization | Azerbaijani UI foundation | Add translation catalog for more languages |
