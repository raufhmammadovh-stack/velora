# Velora Launch Checklist

- [ ] Create production Supabase project
- [ ] Configure `EXPO_PUBLIC_SUPABASE_URL`
- [ ] Configure `EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY`
- [ ] Apply migrations 001→004
- [ ] Create storage buckets + RLS policies
- [ ] Configure email/phone auth provider
- [ ] Configure push notifications
- [ ] Configure WebRTC/TURN or calling provider
- [ ] Configure Edge Function secrets
- [ ] Add CAPTCHA / abuse protection
- [ ] Create the first real admin account securely server-side
- [ ] Test RLS with two ordinary users and one admin
- [ ] Test block/report/discovery exclusion
- [ ] Test account deletion and data cleanup
- [ ] Test rate limits
- [ ] Test moderation workflow
- [ ] Test App Store / Google Play production builds

## No fake activity
Do not run scripts that create users, posts, likes, comments, messages or matches for appearance. Growth must come from real people.
