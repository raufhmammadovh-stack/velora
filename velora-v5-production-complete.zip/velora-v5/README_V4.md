# VELORA V4 — REAL USERS / PUBLIC LAUNCH BUILD

This version extends V3 toward a public-launch architecture.

## Real-user rule
There are **zero** seeded/demo/fake accounts, fake posts, fake likes, fake matches, fake messages, bots or AI personas. Production activity comes only from people who actually register and use Velora.

## Added in V4
- Close Friends
- Favorites
- Message Stars
- Message Pins
- Chat Drafts
- Story Reactions
- Hashtag indexing
- Post mentions
- Support tickets + support messages
- Role-based admin authorization foundation
- Safer discovery view that excludes suspended/deactivated/deleted/blocked accounts
- Online heartbeat / explicit offline function
- Trust & Privacy center
- Remote feature flags service
- Real-user reporting/blocking helpers

## Security principles
- Never ship Supabase secret/service-role credentials in the mobile app.
- Never store plaintext admin passwords in source code or mobile storage.
- Keep privileged admin operations server-side in Edge Functions.
- Use RLS for user-owned data and private conversation membership.
- Add CAPTCHA / abuse protection at public launch and enforce server-side rate limits.

## Database
Apply migrations in order:
1. 001_init.sql
2. 002_expanded.sql
3. 003_real_users_only.sql
4. 004_launch_ready.sql

## Run
npm install
npx expo start

## Production integrations still required
- Supabase project + production environment variables
- Storage buckets and production media policies
- Push notification credentials
- WebRTC/TURN or a managed calling provider for audio/video calls
- App Store / Google Play signing and review configuration
- Production monitoring, backups, email/SMS provider, CAPTCHA/anti-abuse

These are intentionally not faked. Until connected, the app should show an unavailable/not-configured state rather than pretending calls, push or verification are real.
