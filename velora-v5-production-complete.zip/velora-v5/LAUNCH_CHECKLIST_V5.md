# V5 PUBLIC LAUNCH CHECKLIST

## 1. Supabase
- Create production project.
- Run migrations 001 → 005 in SQL Editor.
- Configure Auth email/phone verification.
- Create private/public storage buckets according to the migration policy.
- Set production redirect URLs.
- Never put service-role/secret keys in the mobile app.

## 2. Mobile environment
- Copy `.env.example` to `.env`.
- Set only the publishable Supabase client variables in the app.
- Set an application identifier/package name.
- Configure app icon, splash and deep links.

## 3. Push notifications
- Configure Expo/EAS push credentials.
- Test token registration on a physical Android device.
- Add a trusted server/Edge Function for sending notifications.

## 4. Calls
- Configure WebRTC signaling.
- Configure TURN credentials.
- Test Android → Android audio and video.
- Test background/permission behavior.

## 5. Abuse prevention
- Enable email/phone verification as appropriate.
- Add CAPTCHA/attestation at registration and high-risk actions.
- Add server-side rate limits.
- Monitor reports and suspicious activity.

## 6. Legal
- Publish Privacy Policy, Terms, Community Rules, copyright/reporting process, age policy and support contact.
- Do not launch dating features without an appropriate age gate and store-policy review.

## 7. Store
- Create Google Play Console app.
- Create Apple App Store Connect app if iOS is desired.
- Build signed AAB/IPA with EAS.
- Complete store privacy/data-safety declarations.
- Test deletion and account-data flows before submission.

## 8. Real-user launch
- Start with founder/early-adopter invites.
- Never seed fake accounts or fake activity.
- Monitor crashes, reports, latency, storage and database usage.
