import { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { supabase } from '@/lib/supabase';
import { heartbeat } from '@/services/trust';
import { theme } from '@/lib/theme';

export default function TrustCenter() {
  const [verified, setVerified] = useState(false);
  const [discoverable, setDiscoverable] = useState(true);
  const [nearby, setNearby] = useState(false);
  useEffect(() => { (async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const { data } = await supabase.from('profiles').select('is_verified,discoverable,nearby_enabled').eq('id', user.id).single();
    if (data) { setVerified(!!data.is_verified); setDiscoverable(!!data.discoverable); setNearby(!!data.nearby_enabled); }
    await heartbeat();
  })(); }, []);
  async function update(field: 'discoverable'|'nearby_enabled', value: boolean) {
    const { data: { user } } = await supabase.auth.getUser(); if (!user) return;
    const { error } = await supabase.from('profiles').update({ [field]: value }).eq('id', user.id);
    if (error) Alert.alert('Xəta', error.message); else field === 'discoverable' ? setDiscoverable(value) : setNearby(value);
  }
  return <View style={s.c}><Text style={s.h}>Trust & Privacy</Text><Text style={s.note}>Velora real istifadəçilər üçün nəzərdə tutulub. Heç bir bot və ya saxta profil yaradılmır.</Text>
    <View style={s.row}><View><Text style={s.t}>Hesab təsdiqi</Text><Text style={s.m}>{verified ? 'Təsdiqlənib' : 'Hələ təsdiqlənməyib'}</Text></View></View>
    <TouchableOpacity style={s.row} onPress={() => update('discoverable', !discoverable)}><View><Text style={s.t}>Kəşf edilə bilən hesab</Text><Text style={s.m}>{discoverable ? 'Açıq' : 'Gizli'}</Text></View><Text style={s.v}>{discoverable ? 'ON' : 'OFF'}</Text></TouchableOpacity>
    <TouchableOpacity style={s.row} onPress={() => update('nearby_enabled', !nearby)}><View><Text style={s.t}>Nearby</Text><Text style={s.m}>Yalnız sən aktiv etdikdə işləyir</Text></View><Text style={s.v}>{nearby ? 'ON' : 'OFF'}</Text></TouchableOpacity>
  </View>;
}
const s=StyleSheet.create({c:{flex:1,backgroundColor:theme.bg,padding:20,paddingTop:62},h:{color:theme.text,fontSize:28,fontWeight:'900',marginBottom:12},note:{color:theme.muted,lineHeight:21,marginBottom:22},row:{backgroundColor:theme.card,borderRadius:18,padding:18,marginBottom:12,flexDirection:'row',justifyContent:'space-between',alignItems:'center'},t:{color:theme.text,fontSize:16,fontWeight:'800'},m:{color:theme.muted,marginTop:4},v:{color:theme.accent,fontWeight:'900'}});
