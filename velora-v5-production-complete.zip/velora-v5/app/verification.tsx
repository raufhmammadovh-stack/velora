import React from 'react';
import { View, Text, Pressable, Alert } from 'react-native';
import Screen from '../components/Screen';
import { supabase } from '../lib/supabase';

export default function Verification(){
  const submit = async (method:'email'|'phone') => {
    const { data:{user} } = await supabase.auth.getUser();
    if(!user) return;
    const { error } = await supabase.from('user_verifications').insert({user_id:user.id, method, status:'pending'});
    if(error) Alert.alert('Xəta', error.message); else Alert.alert('Göndərildi','Təsdiq sorğun qəbul edildi.');
  };
  return <Screen title="Hesab təsdiqi"><View style={{gap:14}}>
    <Text style={{fontSize:16}}>Velora-da yalnız real insanların iştirak etməsi üçün hesab təsdiqi seçimlərini buradan idarə edə bilərsən.</Text>
    <Pressable onPress={()=>submit('email')} style={{padding:16,borderRadius:14,backgroundColor:'#222'}}><Text style={{color:'#fff'}}>E-mail təsdiqi</Text></Pressable>
    <Pressable onPress={()=>submit('phone')} style={{padding:16,borderRadius:14,backgroundColor:'#222'}}><Text style={{color:'#fff'}}>Telefon təsdiqi</Text></Pressable>
  </View></Screen>
}
