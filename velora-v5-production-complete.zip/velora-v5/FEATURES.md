# Velora Feature Map

AUTH: signup/login/session/password reset
SOCIAL: profiles/follow requests/feed/likes/comments/replies/saves/reposts/mentions/hashtags
STORIES: 24h stories/views/replies/close friends
DISCOVERY: search/explore/interests/city/nearby architecture
DATING: goals/preferences/age/distance/interests/like/skip/match
CHAT: 1:1/group/messages/reply/edit/delete/forward/react/pin/star/read/typing/archive/mute/drafts
CALLS: signaling interface reserved for WebRTC/TURN provider
NOTIFICATIONS: in-app + push token architecture
SAFETY: block/restrict/report/moderation/audit logs
ADMIN: users/content/reports/support/stats/config/feature flags
CONFIG: remote app name/logo/colors/copy/terms/privacy/onboarding/feature toggles
