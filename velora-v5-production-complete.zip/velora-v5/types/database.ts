export type Profile={id:string;username:string;display_name:string;bio:string|null;avatar_url:string|null;city:string|null;birth_date:string|null;interests:string[];dating_goal:string|null;is_private:boolean;is_verified:boolean;last_seen_at:string|null;is_online:boolean};
export type Post={id:string;author_id:string;caption:string|null;media_url:string;media_type:'image'|'video';created_at:string;author?:Profile;like_count?:number;comment_count?:number;liked?:boolean};
export type Conversation={id:string;title:string|null;is_group:boolean;last_message_at:string|null};
export type Message={id:string;conversation_id:string;sender_id:string;body:string|null;media_url:string|null;message_type:string;created_at:string;edited_at:string|null;deleted_at:string|null};
