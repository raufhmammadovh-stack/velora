# Telefonla (Android) başlama — Azərbaycan dilində

## Ən rahat yol
Telefonun özü ilə layihəni idarə etmək istəyirsənsə, Android Chrome-dan GitHub + GitHub Codespaces kimi brauzer əsaslı development mühitindən istifadə edə bilərsən. Daha rahat və stabil production build üçün isə son mərhələdə kompüter lazımdır.

### 1) ZIP-i kompüterə və ya GitHub-a çıxar
- `velora-v5` qovluğunu GitHub repository-yə yüklə.
- Repository-də `README_V5.md`-ni əsas təlimat kimi saxla.

### 2) Supabase yarat
- Supabase-də yeni project yarat.
- SQL Editor-də `001_init.sql`, `002_expanded.sql`, `003_real_users_only.sql`, `004_launch_ready.sql`, `005_production_core.sql` fayllarını ardıcıllıqla işə sal.
- Project URL və publishable key-i götür.

### 3) Environment
`.env` yarat:
```text
EXPO_PUBLIC_SUPABASE_URL=...
EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY=...
```
Heç vaxt `service_role`/secret key-i mobil tətbiqə qoyma.

### 4) Development test
```bash
npm install
npx expo start
```
Terminaldə çıxan QR kodu telefonla Expo Go ilə aç.

### 5) Production Android
Real Play Store APK/AAB üçün EAS istifadə et:
```bash
npm install -g eas-cli
eas login
eas build:configure
eas build --platform android --profile production
```
Bu addım üçün Google Play hesabı, package/signing məlumatları və EAS konfiqurasiyası tələb olunur.

## İlk real istifadəçi testi
1. Öz real hesabını yarat.
2. E-mail/telefon təsdiqini yoxla.
3. Profil şəklini yüklə.
4. Bir post paylaş.
5. İkinci real test hesabı ilə follow et.
6. Like/comment et.
7. Dating-i test edəcəksənsə yalnız uyğun yaşda real test hesablarından istifadə et.
8. Chat aç və mesaj göndər.
9. Block/report/deactivate/delete axınlarını yoxla.
10. Admin hesabını ayrıca test et.

## Vacib
Launch-dan əvvəl heç bir demo/fake hesab əlavə etmə. Real istifadəçi artımı real qeydiyyatlardan gəlməlidir.
