# Honest production boundary

The source tree contains the application and backend foundation that can be delivered as code. The following cannot be truthfully completed without the owner's external accounts/secrets or operational decisions:

- Supabase production project credentials
- APNs/FCM/Expo push credentials
- WebRTC/TURN credentials or a managed calling provider
- Email/SMS delivery credentials
- CAPTCHA/anti-abuse credentials
- Google Play/App Store developer accounts and signing
- Legal/business information for public Terms and Privacy Policy
- Human moderation staff/process
- Data retention and deletion schedules

These are deliberately represented as integration points, not fake implementations.
