# Velora — Real Users Only Policy

Velora does **not** seed the database with demo profiles, bots, AI personas, fake likes, fake matches, fake comments, fake messages, or synthetic engagement.

Every visible member must originate from a real registration flow. Discovery and dating suggestions are algorithmic ranking of real accounts; they are not AI/bot accounts.

## Anti-fake launch rules
- Email/phone verification enabled.
- Optional stronger identity/manual verification.
- Rate limiting for signup, login, messages, follows, likes and reports.
- Block/report from profile and content.
- Suspended/deactivated/deleted accounts are excluded from discovery.
- Nearby is opt-in and never exposes exact coordinates publicly.
- Admin can moderate accounts but cannot manufacture engagement.
- No hidden bot users or AI-generated personas.
- No fake counters or fake online status.

## Growth model
The app starts empty. You publish it, real people register, and the network grows organically. The database should remain empty of user content until real users create it.
