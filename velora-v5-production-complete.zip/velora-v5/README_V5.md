# VELORA V5 — PRODUCTION / REAL-USERS BUILD

This is the consolidated launch build. It contains no seeded accounts, fake engagement, bots, AI personas, fake matches, fake messages or synthetic activity.

## What is included
- Expo Router mobile app
- Supabase Auth/Postgres/Storage/Realtime foundation
- Real-user-only database rules
- Profiles, follows, posts, comments/replies, saves, reposts
- Stories + reactions + viewers
- Dating preferences, swipes and mutual-match foundation
- Private conversations, group conversations, messages, reactions, stars, pins, drafts
- Online/last-seen heartbeat
- Notifications + device push token storage
- Block/restrict/report + moderation queue
- Verification request workflow
- Support tickets
- Remote feature flags and editable public app configuration
- Admin roles, audit logs, moderation/configuration foundation
- Privacy/security/trust center
- Call signaling data model (provider/TURN credentials must be configured for real audio/video media)
- Account deletion/deactivation flows in the data model
- Hashtag/mention data model

## Production-only dependencies
Some real-world services cannot be created honestly inside a source archive:
1. A Supabase production project and its URL/publishable key.
2. Push credentials (Expo/EAS + APNs/FCM).
3. A real WebRTC/TURN service or managed calling provider.
4. Production email/SMS provider and CAPTCHA/anti-abuse provider.
5. App Store / Google Play developer accounts and signing credentials.
6. Legal text and business contact information for Terms/Privacy/Community Rules.

The app must show an unavailable/not-configured state until these are connected. Nothing is faked.

## Setup
```bash
npm install
cp .env.example .env
# fill EXPO_PUBLIC_SUPABASE_URL and EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY
npx expo start
```

For a real installable Android build, use EAS Build with a development profile first, then a production profile. Expo Go is useful for early UI testing, but native call/notification integrations are best tested with a development build.

## Database
Apply migrations in order, including `005_production_core.sql` after the previous four migrations.

## Admin
Admin access is determined server-side by the `admin_users` table and `is_admin()` RPC. No admin password is embedded in the app source. For production, use a separate privileged authentication flow/Edge Function and MFA/2FA policy.

## Real-user guarantee
No code in this repository creates synthetic users or synthetic engagement. Admin tools can moderate or configure the service but cannot manufacture social proof.
