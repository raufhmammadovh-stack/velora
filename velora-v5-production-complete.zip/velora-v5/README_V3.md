# VELORA V3 — PUBLIC LAUNCH / REAL USERS ONLY

This is the next expansion of the Velora project. It keeps the previous social/dating/chat foundation and adds a stricter real-user trust layer.

### New in V3
- Real-user-only policy
- No seeded users/content/engagement
- Email/phone verification request flow
- Optional identity/manual verification workflow
- Account status and discovery controls
- Device/session tracking foundation
- Last-seen heartbeat
- Server-side rate-limit function
- Block/report helpers
- Discovery exclusions for suspended/deactivated/deleted users
- Nearby is explicitly opt-in
- Security-oriented RLS for trust tables

### Important
Do not put Supabase secret/service keys in the mobile app. Supabase documents that secret/service-role credentials bypass RLS and must remain server-side. Use publishable client credentials in the app and server-side secrets only in Edge Functions/backend. https://supabase.com/docs/guides/database/postgres/row-level-security

For realtime chat, use private channels and authorization policies. Supabase documents private channels and Realtime Authorization for production access control. https://supabase.com/docs/guides/realtime/authorization

### No fake accounts
There is intentionally no seed script. No bots. No AI personas. No fake engagement. The first user in production is the first real registrant.

### Run
npm install
npx expo start

Apply migrations in order:
001_init.sql
002_expanded.sql
003_real_users_only.sql
