export const theme={bg:'#0B0D12',card:'#151922',card2:'#1D2230',text:'#F6F7FB',muted:'#9CA3B4',accent:'#8B5CF6',accent2:'#EC4899',success:'#22C55E',danger:'#EF4444',border:'#272D3A'};
