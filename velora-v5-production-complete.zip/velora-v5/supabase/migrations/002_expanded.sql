-- Velora expanded social graph, messaging, moderation and remote configuration.
create table if not exists public.saved_posts(id uuid primary key default gen_random_uuid(),post_id uuid references public.posts(id) on delete cascade,user_id uuid references public.profiles(id) on delete cascade,created_at timestamptz default now(),unique(post_id,user_id));
create table if not exists public.reposts(id uuid primary key default gen_random_uuid(),post_id uuid references public.posts(id) on delete cascade,user_id uuid references public.profiles(id) on delete cascade,created_at timestamptz default now(),unique(post_id,user_id));
create table if not exists public.matches(id uuid primary key default gen_random_uuid(),user_a uuid references public.profiles(id) on delete cascade,user_b uuid references public.profiles(id) on delete cascade,created_at timestamptz default now(),status text default 'active');
create table if not exists public.reports(id uuid primary key default gen_random_uuid(),reporter_id uuid references public.profiles(id),target_type text not null,target_id uuid,reason text not null,status text default 'open',created_at timestamptz default now());
create table if not exists public.app_config(key text primary key,value text not null,type text not null default 'text',description text,updated_at timestamptz default now());
insert into public.app_config(key,value,type) values
('app_name','VELORA','text'),('primary_color','#8B5CF6','text'),('registration_enabled','true','boolean'),('chat_enabled','true','boolean'),('story_enabled','true','boolean'),('dating_enabled','true','boolean'),('match_enabled','true','boolean'),('nearby_enabled','false','boolean'),('calls_enabled','false','boolean'),('comments_enabled','true','boolean'),('reposts_enabled','true','boolean'),('maintenance_mode','false','boolean') on conflict(key) do nothing;
alter table public.app_config enable row level security;
create or replace function public.is_admin() returns boolean language sql security definer set search_path=public as $$ select exists(select 1 from public.admins where user_id=auth.uid() and active=true); $$;
create policy "public can read enabled app config" on public.app_config for select using (true);
create policy "admins can modify config" on public.app_config for all using (public.is_admin()) with check (public.is_admin());
alter table public.saved_posts enable row level security;
create policy "users manage own saves" on public.saved_posts for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
alter table public.reposts enable row level security;
create policy "users manage own reposts" on public.reposts for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
alter table public.matches enable row level security;
create policy "match participants read" on public.matches for select using (auth.uid()=user_a or auth.uid()=user_b);
create policy "users create matches" on public.matches for insert with check (auth.uid()=user_a or auth.uid()=user_b);
alter table public.reports enable row level security;
create policy "users create reports" on public.reports for insert with check (auth.uid()=reporter_id);
create policy "admins manage reports" on public.reports for all using (public.is_admin()) with check (public.is_admin());
