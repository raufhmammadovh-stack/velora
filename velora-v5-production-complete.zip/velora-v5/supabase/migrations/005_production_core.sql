-- VELORA V5 production core. No synthetic users or engagement.

alter table public.push_tokens add column if not exists updated_at timestamptz not null default now();
create unique index if not exists idx_push_tokens_user_token on public.push_tokens(user_id, token);

alter table public.profiles add column if not exists restricted_until timestamptz;
alter table public.profiles add column if not exists deleted_at timestamptz;
alter table public.profiles add column if not exists updated_at timestamptz not null default now();

create table if not exists public.user_restrictions(
  restrictor_id uuid not null references auth.users(id) on delete cascade,
  restricted_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(restrictor_id, restricted_id), check(restrictor_id<>restricted_id)
);
create table if not exists public.calls(
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  caller_id uuid not null references auth.users(id) on delete cascade,
  callee_id uuid not null references auth.users(id) on delete cascade,
  kind text not null check(kind in ('audio','video')),
  status text not null default 'ringing' check(status in ('ringing','accepted','rejected','ended','missed')),
  created_at timestamptz not null default now(),
  ended_at timestamptz
);
create index if not exists idx_calls_participants on public.calls(caller_id,callee_id,created_at desc);
create table if not exists public.call_signals(
  id bigint generated always as identity primary key,
  call_id uuid not null references public.calls(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  signal_type text not null check(signal_type in ('offer','answer','ice','hangup')),
  payload jsonb not null,
  created_at timestamptz not null default now()
);
create table if not exists public.restricts(
  restrictor_id uuid not null references auth.users(id) on delete cascade,
  restricted_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(restrictor_id,restricted_id), check(restrictor_id<>restricted_id)
);
create table if not exists public.account_deletion_requests(
  user_id uuid primary key references auth.users(id) on delete cascade,
  requested_at timestamptz not null default now(),
  execute_after timestamptz not null default now()+interval '7 days',
  cancelled_at timestamptz
);
create table if not exists public.admin_actions(
  id uuid primary key default gen_random_uuid(),
  admin_user_id uuid not null references auth.users(id),
  action text not null,
  target_type text,
  target_id uuid,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);

alter table public.user_restrictions enable row level security;
alter table public.calls enable row level security;
alter table public.call_signals enable row level security;
alter table public.restricts enable row level security;
alter table public.account_deletion_requests enable row level security;
alter table public.admin_actions enable row level security;

create policy "restrictions own" on public.user_restrictions for all to authenticated using(auth.uid()=restrictor_id) with check(auth.uid()=restrictor_id and restrictor_id<>restricted_id);
create policy "calls participants" on public.calls for select to authenticated using(auth.uid()=caller_id or auth.uid()=callee_id);
create policy "calls caller insert" on public.calls for insert to authenticated with check(auth.uid()=caller_id and exists(select 1 from public.conversation_members cm where cm.conversation_id=conversation_id and cm.user_id=auth.uid()));
create policy "calls participant update" on public.calls for update to authenticated using(auth.uid()=caller_id or auth.uid()=callee_id) with check(auth.uid()=caller_id or auth.uid()=callee_id);
create policy "signals participants" on public.call_signals for all to authenticated using(exists(select 1 from public.calls c where c.id=call_id and (c.caller_id=auth.uid() or c.callee_id=auth.uid()))) with check(auth.uid()=sender_id and exists(select 1 from public.calls c where c.id=call_id and (c.caller_id=auth.uid() or c.callee_id=auth.uid())));
create policy "restricts own" on public.restricts for all to authenticated using(auth.uid()=restrictor_id) with check(auth.uid()=restrictor_id and restrictor_id<>restricted_id);
create policy "deletion own" on public.account_deletion_requests for all to authenticated using(auth.uid()=user_id) with check(auth.uid()=user_id);
create policy "admin actions own" on public.admin_actions for select to authenticated using(auth.uid()=admin_user_id);

create or replace function public.get_discoverable_profiles(p_limit integer default 30)
returns setof public.profiles language sql security definer set search_path=public as $$
  select p.* from public.profiles p
  where p.account_status='active' and p.discoverable=true and p.id<>auth.uid()
    and not exists(select 1 from public.user_blocks b where b.blocker_id=auth.uid() and b.blocked_id=p.id)
    and not exists(select 1 from public.user_blocks b where b.blocker_id=p.id and b.blocked_id=auth.uid())
    and not exists(select 1 from public.restricts r where r.restrictor_id=auth.uid() and r.restricted_id=p.id)
  order by p.last_seen_at desc nulls last, p.created_at desc limit greatest(1,least(p_limit,100));
$$;
grant execute on function public.get_discoverable_profiles(integer) to authenticated;

create or replace function public.get_dating_candidates(p_limit integer default 20)
returns setof public.profiles language sql security definer set search_path=public as $$
  select p.* from public.profiles p
  left join public.dating_preferences dp on dp.user_id=auth.uid()
  where p.account_status='active' and p.discoverable=true and p.id<>auth.uid()
    and p.dating_goal is not null
    and not exists(select 1 from public.dating_swipes s where s.actor_id=auth.uid() and s.target_id=p.id)
    and not exists(select 1 from public.user_blocks b where (b.blocker_id=auth.uid() and b.blocked_id=p.id) or (b.blocker_id=p.id and b.blocked_id=auth.uid()))
    and not exists(select 1 from public.user_restrictions r where (r.restrictor_id=auth.uid() and r.restricted_id=p.id) or (r.restrictor_id=p.id and r.restricted_id=auth.uid()))
    and (dp.goals is null or cardinality(dp.goals)=0 or p.dating_goal = any(dp.goals))
    and (dp.min_age is null or extract(year from age(current_date,p.birth_date)) >= dp.min_age)
    and (dp.max_age is null or extract(year from age(current_date,p.birth_date)) <= dp.max_age)
  order by p.last_seen_at desc nulls last, p.created_at desc limit greatest(1,least(p_limit,100));
$$;
grant execute on function public.get_dating_candidates(integer) to authenticated;

create or replace function public.touch_last_seen() returns void language sql security definer set search_path=public as $$
 update public.profiles set last_seen_at=now(),is_online=true,updated_at=now() where id=auth.uid();
$$;
grant execute on function public.touch_last_seen() to authenticated;

create or replace function public.deactivate_my_account() returns void language plpgsql security definer set search_path=public as $$
begin update public.profiles set account_status='deactivated',discoverable=false,is_online=false,updated_at=now() where id=auth.uid(); end;
$$;
grant execute on function public.deactivate_my_account() to authenticated;

create or replace function public.request_account_deletion() returns void language plpgsql security definer set search_path=public as $$
begin
 insert into public.account_deletion_requests(user_id) values(auth.uid()) on conflict(user_id) do update set requested_at=now(),execute_after=now()+interval '7 days',cancelled_at=null;
 update public.profiles set account_status='deactivated',discoverable=false,is_online=false,updated_at=now() where id=auth.uid();
end;
$$;
grant execute on function public.request_account_deletion() to authenticated;

create or replace function public.is_admin() returns boolean language sql security definer set search_path=public as $$
 select public.has_admin_role(null);
$$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

-- Prevent clients from modifying app configuration directly. Admin changes should go through privileged server code.
drop policy if exists "config public read" on public.app_config;
create policy "config public read" on public.app_config for select to authenticated using(true);

-- Ensure push token updates remain user-owned.
drop policy if exists "push tokens own" on public.push_tokens;
create policy "push tokens own" on public.push_tokens for all to authenticated using(auth.uid()=user_id) with check(auth.uid()=user_id);

-- Helpful indexes for launch workloads.
create index if not exists idx_posts_author_created on public.posts(author_id,created_at desc);
create index if not exists idx_messages_conversation_created on public.messages(conversation_id,created_at desc);
create index if not exists idx_notifications_user_created on public.notifications(user_id,created_at desc);
create index if not exists idx_story_expiry on public.stories(expires_at);
create index if not exists idx_profiles_last_seen on public.profiles(last_seen_at desc);

comment on schema public is 'Velora production schema. No synthetic accounts or engagement are created by migrations.';
