-- Velora V3: real-user-only foundation. No seed users, bots, AI profiles, or fake engagement.
create extension if not exists pgcrypto;

alter table public.profiles add column if not exists account_status text not null default 'active' check (account_status in ('active','deactivated','suspended','deleted'));
alter table public.profiles add column if not exists is_verified boolean not null default false;
alter table public.profiles add column if not exists verification_method text;
alter table public.profiles add column if not exists date_of_birth date;
alter table public.profiles add column if not exists city text;
alter table public.profiles add column if not exists country text;
alter table public.profiles add column if not exists discoverable boolean not null default true;
alter table public.profiles add column if not exists nearby_enabled boolean not null default false;
alter table public.profiles add column if not exists last_seen_at timestamptz;

create table if not exists public.user_devices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  device_hash text not null,
  platform text,
  push_token text,
  created_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  unique(user_id, device_hash)
);

create table if not exists public.user_verifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  method text not null check (method in ('email','phone','identity','manual')),
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  reviewed_by uuid references auth.users(id),
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.user_blocks (
  blocker_id uuid not null references auth.users(id) on delete cascade,
  blocked_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id),
  check (blocker_id <> blocked_id)
);

create table if not exists public.rate_limit_events (
  id bigint generated always as identity primary key,
  user_id uuid references auth.users(id) on delete cascade,
  action text not null,
  created_at timestamptz not null default now()
);

create index if not exists idx_rate_limit_user_action_time on public.rate_limit_events(user_id, action, created_at desc);
create index if not exists idx_profiles_discovery on public.profiles(account_status, discoverable, nearby_enabled);

alter table public.user_devices enable row level security;
alter table public.user_verifications enable row level security;
alter table public.user_blocks enable row level security;
alter table public.rate_limit_events enable row level security;

create policy "devices own rows" on public.user_devices for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "verification own rows" on public.user_verifications for select to authenticated using (auth.uid() = user_id);
create policy "blocks own rows" on public.user_blocks for all to authenticated using (auth.uid() = blocker_id) with check (auth.uid() = blocker_id and blocker_id <> blocked_id);
create policy "rate events own read" on public.rate_limit_events for select to authenticated using (auth.uid() = user_id);

create or replace function public.touch_last_seen()
returns void language sql security definer set search_path=public
as $$
  update public.profiles set last_seen_at = now() where id = auth.uid();
$$;

create or replace function public.consume_rate_limit(p_action text, p_limit integer, p_window_seconds integer)
returns boolean language plpgsql security definer set search_path=public
as $$
declare n integer;
begin
  if auth.uid() is null then return false; end if;
  select count(*) into n from public.rate_limit_events
   where user_id=auth.uid() and action=p_action and created_at > now() - make_interval(secs => p_window_seconds);
  if n >= p_limit then return false; end if;
  insert into public.rate_limit_events(user_id, action) values(auth.uid(), p_action);
  return true;
end;
$$;

revoke all on function public.consume_rate_limit(text, integer, integer) from public;
grant execute on function public.consume_rate_limit(text, integer, integer) to authenticated;
grant execute on function public.touch_last_seen() to authenticated;

-- IMPORTANT: this migration intentionally creates no demo accounts, posts, likes, matches, chats, bots, or AI users.
