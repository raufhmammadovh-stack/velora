-- VELORA V4: launch-ready social graph, moderation, privacy and remote controls.
-- IMPORTANT: intentionally contains ZERO seed/demo/fake accounts or engagement.

create table if not exists public.close_friends(
  owner_id uuid references auth.users(id) on delete cascade,
  friend_id uuid references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(owner_id,friend_id), check(owner_id<>friend_id)
);
create table if not exists public.favorites(
  user_id uuid references auth.users(id) on delete cascade,
  favorite_id uuid references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id,favorite_id), check(user_id<>favorite_id)
);
create table if not exists public.message_stars(
  user_id uuid references auth.users(id) on delete cascade,
  message_id uuid references public.messages(id) on delete cascade,
  created_at timestamptz not null default now(), primary key(user_id,message_id)
);
create table if not exists public.message_pins(
  conversation_id uuid references public.conversations(id) on delete cascade,
  message_id uuid references public.messages(id) on delete cascade,
  pinned_by uuid references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(conversation_id,message_id)
);
create table if not exists public.message_drafts(
  user_id uuid references auth.users(id) on delete cascade,
  conversation_id uuid references public.conversations(id) on delete cascade,
  body text not null default '',
  updated_at timestamptz not null default now(),
  primary key(user_id,conversation_id)
);
create table if not exists public.story_reactions(
  story_id uuid references public.stories(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade,
  emoji text not null,
  created_at timestamptz not null default now(),
  primary key(story_id,user_id)
);
create table if not exists public.post_hashtags(
  post_id uuid references public.posts(id) on delete cascade,
  hashtag text not null,
  primary key(post_id,hashtag)
);
create index if not exists idx_post_hashtags_tag on public.post_hashtags(hashtag);
create table if not exists public.post_mentions(
  post_id uuid references public.posts(id) on delete cascade,
  mentioned_user_id uuid references auth.users(id) on delete cascade,
  primary key(post_id,mentioned_user_id)
);
create table if not exists public.support_tickets(
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  subject text not null,
  message text not null,
  status text not null default 'open' check(status in ('open','pending','resolved','closed')),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.support_messages(
  id uuid primary key default gen_random_uuid(),
  ticket_id uuid references public.support_tickets(id) on delete cascade,
  sender_id uuid references auth.users(id) on delete cascade,
  body text not null, created_at timestamptz not null default now()
);
create table if not exists public.admin_roles(
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'moderator' check(role in ('owner','admin','moderator','support','analyst')),
  active boolean not null default true, created_at timestamptz not null default now()
);
create index if not exists idx_admin_roles_active on public.admin_roles(active,role);

alter table public.close_friends enable row level security;
alter table public.favorites enable row level security;
alter table public.message_stars enable row level security;
alter table public.message_pins enable row level security;
alter table public.message_drafts enable row level security;
alter table public.story_reactions enable row level security;
alter table public.post_hashtags enable row level security;
alter table public.post_mentions enable row level security;
alter table public.support_tickets enable row level security;
alter table public.support_messages enable row level security;
alter table public.admin_roles enable row level security;

create policy "close friends own" on public.close_friends for all to authenticated using(auth.uid()=owner_id) with check(auth.uid()=owner_id and owner_id<>friend_id);
create policy "favorites own" on public.favorites for all to authenticated using(auth.uid()=user_id) with check(auth.uid()=user_id and user_id<>favorite_id);
create policy "stars own" on public.message_stars for all to authenticated using(auth.uid()=user_id) with check(auth.uid()=user_id);
create policy "pins members" on public.message_pins for all to authenticated using(exists(select 1 from public.conversation_members cm where cm.conversation_id=conversation_id and cm.user_id=auth.uid())) with check(exists(select 1 from public.conversation_members cm where cm.conversation_id=conversation_id and cm.user_id=auth.uid()));
create policy "drafts own" on public.message_drafts for all to authenticated using(auth.uid()=user_id) with check(auth.uid()=user_id);
create policy "story reactions own" on public.story_reactions for all to authenticated using(auth.uid()=user_id) with check(auth.uid()=user_id);
create policy "hashtags public read" on public.post_hashtags for select to authenticated using(true);
create policy "hashtags author write" on public.post_hashtags for all to authenticated using(exists(select 1 from public.posts p where p.id=post_id and p.author_id=auth.uid())) with check(exists(select 1 from public.posts p where p.id=post_id and p.author_id=auth.uid()));
create policy "mentions public read" on public.post_mentions for select to authenticated using(true);
create policy "mentions author write" on public.post_mentions for all to authenticated using(exists(select 1 from public.posts p where p.id=post_id and p.author_id=auth.uid())) with check(exists(select 1 from public.posts p where p.id=post_id and p.author_id=auth.uid()));
create policy "tickets own" on public.support_tickets for all to authenticated using(auth.uid()=user_id) with check(auth.uid()=user_id);
create policy "support messages ticket owner" on public.support_messages for select to authenticated using(exists(select 1 from public.support_tickets t where t.id=ticket_id and t.user_id=auth.uid()));
create policy "support message owner insert" on public.support_messages for insert to authenticated with check(auth.uid()=sender_id and exists(select 1 from public.support_tickets t where t.id=ticket_id and t.user_id=auth.uid()));
create policy "admin roles own read" on public.admin_roles for select to authenticated using(auth.uid()=user_id);

-- Discovery must never surface non-active/non-discoverable users.
create or replace view public.discoverable_profiles as
select p.* from public.profiles p
where p.account_status='active' and p.discoverable=true and p.id<>auth.uid()
  and not exists(select 1 from public.user_blocks b where b.blocker_id=auth.uid() and b.blocked_id=p.id)
  and not exists(select 1 from public.user_blocks b where b.blocker_id=p.id and b.blocked_id=auth.uid());

create or replace function public.touch_last_seen() returns void language sql security definer set search_path=public as $$
  update public.profiles set last_seen_at=now(), is_online=true where id=auth.uid();
$$;
grant execute on function public.touch_last_seen() to authenticated;

-- Clean online status without inventing activity: callers must heartbeat.
create or replace function public.set_offline() returns void language sql security definer set search_path=public as $$
  update public.profiles set is_online=false where id=auth.uid();
$$;
grant execute on function public.set_offline() to authenticated;

-- Admin authorization is role based; no admin secret is shipped in the client.
create or replace function public.has_admin_role(required_role text default null) returns boolean
language sql security definer set search_path=public as $$
  select exists(select 1 from public.admin_roles ar where ar.user_id=auth.uid() and ar.active=true and (required_role is null or ar.role=required_role or ar.role='owner' or ar.role='admin'));
$$;
revoke all on function public.has_admin_role(text) from public;
grant execute on function public.has_admin_role(text) to authenticated;

-- Keep configuration safe for clients: public values only. Secrets belong in Edge Functions.
comment on table public.admin_roles is 'Role assignment only; never store plaintext admin passwords or secrets here.';
