import { supabase } from '@/lib/supabase';

export async function saveDraft(conversationId: string, body: string) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('Authentication required');
  return supabase.from('message_drafts').upsert({ user_id: user.id, conversation_id: conversationId, body, updated_at: new Date().toISOString() });
}

export async function getDraft(conversationId: string) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  const { data } = await supabase.from('message_drafts').select('body').eq('user_id', user.id).eq('conversation_id', conversationId).maybeSingle();
  return data?.body ?? '';
}

export async function starMessage(messageId: string) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('Authentication required');
  return supabase.from('message_stars').upsert({ user_id: user.id, message_id: messageId });
}
