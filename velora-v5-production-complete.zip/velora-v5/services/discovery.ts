import { supabase } from '@/lib/supabase';

export async function getDiscoverableProfiles(limit = 30) {
  const { data, error } = await supabase.rpc('get_discoverable_profiles', { p_limit: limit });
  return { data: data ?? [], error };
}

export async function getDatingCandidates(limit = 20) {
  const { data, error } = await supabase.rpc('get_dating_candidates', { p_limit: limit });
  return { data: data ?? [], error };
}
