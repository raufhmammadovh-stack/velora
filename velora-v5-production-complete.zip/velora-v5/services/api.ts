import {supabase} from '@/lib/supabase';

export async function toggleLike(postId:string,userId:string){
 const {data}=await supabase.from('post_likes').select('post_id').eq('post_id',postId).eq('user_id',userId).maybeSingle();
 if(data) return supabase.from('post_likes').delete().eq('post_id',postId).eq('user_id',userId);
 return supabase.from('post_likes').insert({post_id:postId,user_id:userId});
}
export async function createPost(userId:string,mediaUrl:string,mediaType:'image'|'video',caption:string){return supabase.from('posts').insert({author_id:userId,media_url:mediaUrl,media_type:mediaType,caption}).select().single()}
export async function sendMessage(conversationId:string,senderId:string,body:string){return supabase.from('messages').insert({conversation_id:conversationId,sender_id:senderId,body,message_type:'text'}).select().single()}
export async function reactToMessage(messageId:string,userId:string,emoji:string){return supabase.from('message_reactions').upsert({message_id:messageId,user_id:userId,emoji})}
export async function swipe(targetId:string,actorId:string,action:'like'|'skip'){return supabase.from('dating_swipes').upsert({actor_id:actorId,target_id:targetId,action})}
