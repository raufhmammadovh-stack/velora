import { supabase } from '@/lib/supabase';

export type CallKind = 'audio' | 'video';

export async function createCall(conversationId: string, calleeId: string, kind: CallKind) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('Authentication required');
  return supabase.from('calls').insert({ conversation_id: conversationId, caller_id: user.id, callee_id: calleeId, kind, status: 'ringing' }).select().single();
}

export async function updateCall(callId: string, status: 'ringing'|'accepted'|'rejected'|'ended'|'missed') {
  return supabase.from('calls').update({ status, ended_at: status === 'ended' || status === 'rejected' || status === 'missed' ? new Date().toISOString() : null }).eq('id', callId);
}

export function subscribeToCall(callId: string, cb: (payload: any) => void) {
  const channel = supabase.channel(`call:${callId}`, { config: { private: true } }).on('postgres_changes', { event: '*', schema: 'public', table: 'calls', filter: `id=eq.${callId}` }, cb).subscribe();
  return () => { supabase.removeChannel(channel); };
}
