import {supabase} from '@/lib/supabase';
export const follow=async(follower_id:string,following_id:string)=>supabase.from('follows').upsert({follower_id,following_id,status:'pending'});
export const unfollow=async(follower_id:string,following_id:string)=>supabase.from('follows').delete().eq('follower_id',follower_id).eq('following_id',following_id);
export const addComment=async(post_id:string,user_id:string,body:string,parent_id?:string)=>supabase.from('comments').insert({post_id,author_id:user_id,body,parent_id});
export const savePost=async(post_id:string,user_id:string)=>supabase.from('saved_posts').upsert({post_id,user_id});
export const repost=async(post_id:string,user_id:string)=>supabase.from('reposts').upsert({post_id,user_id});
export const createMatch=async(user_a:string,user_b:string)=>supabase.from('matches').insert({user_a,user_b});
export const report=async(reporter_id:string,target_type:string,target_id:string,reason:string)=>supabase.from('reports').insert({reporter_id,target_type,target_id,reason});
