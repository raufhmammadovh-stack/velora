import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { supabase } from '@/lib/supabase';

export async function registerPushToken() {
  const permissions = await Notifications.getPermissionsAsync();
  let status = permissions.status;
  if (status !== 'granted') {
    const requested = await Notifications.requestPermissionsAsync();
    status = requested.status;
  }
  if (status !== 'granted') return { error: new Error('Notification permission denied') };
  const token = (await Notifications.getExpoPushTokenAsync()).data;
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { error: new Error('Authentication required') };
  return supabase.from('push_tokens').upsert({ user_id: user.id, token, platform: Platform.OS, updated_at: new Date().toISOString() }, { onConflict: 'user_id,token' });
}
