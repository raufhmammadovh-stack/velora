import { supabase } from '@/lib/supabase';

export async function uploadMedia(uri: string, userId: string, contentType: string) {
  const response = await fetch(uri);
  const blob = await response.blob();
  const ext = contentType.includes('video') ? 'mp4' : 'jpg';
  const path = `${userId}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
  const { data, error } = await supabase.storage.from('media').upload(path, blob, { contentType, upsert: false });
  if (error) throw error;
  const publicUrl = supabase.storage.from('media').getPublicUrl(data.path).data.publicUrl;
  return { path: data.path, publicUrl };
}
