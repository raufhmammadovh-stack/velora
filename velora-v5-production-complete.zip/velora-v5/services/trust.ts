import { supabase } from '@/lib/supabase';

export async function heartbeat() {
  return supabase.rpc('touch_last_seen');
}

export async function goOffline() {
  return supabase.rpc('set_offline');
}

export async function report(targetType: string, targetId: string, reason: string, details = '') {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('Authentication required');
  return supabase.from('reports').insert({ reporter_id: user.id, target_type: targetType, target_id: targetId, reason, details });
}

export async function blockUser(blockedId: string) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('Authentication required');
  return supabase.from('user_blocks').upsert({ blocker_id: user.id, blocked_id: blockedId });
}
