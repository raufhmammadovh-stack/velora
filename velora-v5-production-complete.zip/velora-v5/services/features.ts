import { supabase } from '@/lib/supabase';

export type FeatureKey =
  | 'registration_enabled' | 'chat_enabled' | 'story_enabled' | 'dating_enabled'
  | 'match_enabled' | 'nearby_enabled' | 'calls_enabled' | 'comments_enabled'
  | 'reposts_enabled';

export async function getFeature(key: FeatureKey, fallback = true) {
  const { data, error } = await supabase.from('app_config').select('value,type').eq('key', key).maybeSingle();
  if (error || !data) return fallback;
  return data.type === 'boolean' ? data.value === 'true' : data.value === 'true';
}

export async function getPublicConfig() {
  const { data } = await supabase.from('app_config').select('key,value,type').order('key');
  return data ?? [];
}
