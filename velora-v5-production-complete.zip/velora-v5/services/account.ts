import { supabase } from '@/lib/supabase';

export async function deactivateAccount() {
  return supabase.rpc('deactivate_my_account');
}

export async function requestAccountDeletion() {
  return supabase.rpc('request_account_deletion');
}
